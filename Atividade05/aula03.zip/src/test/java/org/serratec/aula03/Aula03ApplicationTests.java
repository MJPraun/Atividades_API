package org.serratec.aula03;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aula03ApplicationTests {

	@Test
	void contextLoads() {
	}

}
